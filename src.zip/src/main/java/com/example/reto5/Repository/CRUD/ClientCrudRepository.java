package com.example.reto5.Repository.CRUD;

import com.example.reto5.Model.Client;
import org.springframework.data.repository.CrudRepository;

public interface ClientCrudRepository extends CrudRepository<Client, Integer> {
}
